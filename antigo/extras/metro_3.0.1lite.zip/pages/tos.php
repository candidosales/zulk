<script>
menuLink = new Array(); 
menuColor = new Array();
$mainNav.set("home");
</script>
<h1 class="margin-t-0">Terms of Use</h1>
<p>This is the lite version of a template that is developed by Thomas Verelst and may only be used for testing purposes. Check on this version how the basic things like setting up tiles work and test if it works. For real web usage, go to  <a href="http://metro-webdesign.info">Metro-Webdesign.info </a> and donate.You can choose the amount to donate.  By donating, you will get the full version with much more cool tiles, a compressing system, a mobile version, a no-javascript version,an Admin Panel with file-editing, better support... <br />
If you have questions, go to <a href="http://metro-webdesign.info">Metro-Webdesign.info </a> and contact me.

<h3>Why is the full version only for donators?</h3>
<p>I worked hard, very hard for v3 of this template. It has many features and getting this bug-free is really a pain in some browsers (Ahum, Internet Explorer). Also, I found optimizing this template very important. I used the latest techniques, with fallbacks for older browsers and I've optimized the javascript code as much as possible, I even added a compression system to ensure the performance of your site is good. I've tried to make this optimized for SEO (which isn't obvious for an AJAX template), and work on mobile phones with the mobile version. Also, writing tutorials isn't always fun and I also try to give support when you have a problem. You can ask support on the site.

<p><small>All rights reserved to Thomas Verelst. Do not redistribute, copy or sell this template, nor claim this is your own work. I am not responsible for things that happen with your site. If you have problems or questions, I try to help as much as I can, but I give no warranty.  </small>

<h3>Thanks to</h3>
<ul>
<li>The creators of jQuery</li>
<li>Brandon Aaron for his mousewheel plugin</li>
<li>Ben Alman for his jquery hashchange event</li>
<li>Tino Zijdel for his js minifier script</li>
</ul>
