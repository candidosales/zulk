<script>
menuLink = new Array(); 
menuLink['Images 1'] = 'Images 1';
menuLink['Images 2'] = 'Images 2';
menuLink['Images 3'] = 'Images 3'

menuColor = new Array();
menuColor['Images 1'] = "#C33";
menuColor['Images 2'] = "#C33";
menuColor['Images 3'] = "#C33";
$mainNav.set("my_images")
</script>

<h1 class="margin-t-0">Title</h1>
<p>Text