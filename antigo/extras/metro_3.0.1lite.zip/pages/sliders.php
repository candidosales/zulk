<script>
menuLink = new Array(); 
menuLink['Slider Example Page'] = 'Slider Example';
menuLink['Typography Tutorial'] = 'Typography';

menuColor = new Array();
menuColor['Slider Example Page'] = "#F60";
menuColor['Typography Tutorial'] = "#F60";
$mainNav.set("home")
</script>
<script type="text/javascript" src='js/inc/contentslider.js'></script>
<h1 class="margin-t-0">Sliders</h1>
<em style='margin-left:20px;'>View the source for code</em>
<br/><br/>
<div class="sliderWrapper" id="closeOther">
	<div class="sliderHead">
    <img src="img/arrows/arrowRight.png" class="sliderImage"/>
    <h2>Title</h2>
    </div>
	<div class="sliderContent">
    	Content
	</div>
</div>

<div class="sliderWrapper" id="closeOther">
	<div class="sliderHead">
    <img src="img/arrows/arrowRight.png" class="sliderImage"/>
    <h2>Example</h2>
    </div>
	<div class="sliderContent">
    	<h3 class="margin-t-0">Subtitle</h3>
		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam vestibulum felis non metus porta lobortis. Integer volutpat vestibulum semper. Mauris ac neque eget ante lobortis ullamcorper. Maecenas sit amet diam eget dui congue condimentum. Mauris posuere, ligula id gravida gravida, turpis sem malesuada erat, sit amet eleifend odio justo elementum nibh. Praesent rhoncus tellus nec orci commodo pellentesque.</p>
	   <hr />
	   <h3>Second part</h3> Quisque tristique justo ut tortor facilisis pulvinar. Sed mollis, turpis vel tincidunt pharetra, mi diam elementum odio, sed fermentum mi purus non odio. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas semper lectus eget dui gravida faucibus. Aenean fringilla dui nec leo aliquet sit amet vehicula ante fringilla. Praesent vestibulum malesuada mauris vel eleifend. Morbi aliquam suscipit odio, id congue velit elementum vitae. Pellentesque ac eros quis lorem dignissim placerat vitae sed elit.
	</div>
</div>


<div class="size-auto" style="text-align:right">
	<a href="#!Slider_example&show_all" style="margin-top:20px;font-size:10px;"><button class="orangeButton">Show all</button></a>
	<a href="#!Slider_example" style="margin-top:20px;font-size:10px;"><button class="orangeButton">Hide all</button></a>
</div>