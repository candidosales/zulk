    
                          _                   _     
     _ __ ___   ___   ___| |_ _ __ _   _  ___| |__  
    | '_ ` _ \ / _ \ / __| __| '__| | | |/ __| '_ \ 
    | | | | | | (_) | (__| |_| |  | |_| | (__| | | |
    |_| |_| |_|\___/ \___|\__|_|   \__,_|\___|_| |_|
    

Moctruch
====
Moctruch is an experiment inspired by [JS NEWS group on Facebook](https://www.facebook.com/groups/217169631654737/permalink/566491106722586/) in which I tried to emulate iOS7 like blurred overlay in HTML5. It reacts to DOM changes of the layers below (more or less). Firefox only so far. iOS7 template stolen from [Recombu](http://recombu.com/mobile/interactive/iphone-5s-ios7-concept/).

Click here for the [DEMO](http://michalbe.github.io/moctruch/).

Michal [@michalbe](http://twitter.com/michalbe) Budzynski, [13.07.2013](http://en.wikipedia.org/wiki/13_July)

===
Moctruch is a creature from Polish mythology that urinates during major & important events and holidays, such as Christmas or Easter, known from the folk song - *"[Bóg się rodzi, Moctruch leje!](http://www.youtube.com/watch?v=Y2Ror4pIKp8)"*.