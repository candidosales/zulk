A Pen created at CodePen.io. You can find this one at http://codepen.io/candidosales/pen/KLgjB.

 Realtime blurrring like in iOS 7, uses CSS blur, so your browser better support it.