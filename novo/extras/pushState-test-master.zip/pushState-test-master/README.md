To run, get `lighttpd`, run with `lighttpd -D -f config`, open your browser to `localhost:3003`
