css-blur
========

A recreation of the iOS7 blur effect using CSS3 filters.
